"""The four tools that are always bound to the LLM, regardless of retrieval:
  search_tools     - escape hatch: ask the registry for more tools
  rag_search       - Retrieval-Augmented Generation over the knowledge base
  system_search    - query the system itself (capabilities catalogue, or run history)
  aggregate_result - do arithmetic over a stored tool result in code, not in the LLM's head
"""


def _fn(name, desc, props, required):
    return {"type": "function", "function": {"name": name, "description": desc,
            "parameters": {"type": "object", "properties": props, "required": required}}}


META_TOOLS = [
    _fn("search_tools",
        "Look for additional API tools when none of the currently available tools fit the task. "
        "Describe the ACTION you need in a few words (e.g. 'refund a payment'). Newly found tools become callable on your next step.",
        {"query": {"type": "string"}}, ["query"]),
    _fn("rag_search",
        "Search the product documentation / how-to guides / policies knowledge base. Use for 'how do I...', 'what does X mean', "
        "fees, limits, policies. Returns passages with their source file. Do NOT use for account data.",
        {"query": {"type": "string"}}, ["query"]),
    _fn("system_search",
        "Ask about the assistant itself. scope='tools': which capabilities/tools exist (e.g. 'what can manage invoices'). "
        "scope='runs': history and status of this user's recent requests and tool calls (e.g. 'status of my last request').",
        {"scope": {"type": "string", "enum": ["tools", "runs"]}, "query": {"type": "string"}}, ["scope"]),
    _fn("aggregate_result",
        "Compute sum/count/avg/min/max over a list inside a previous tool result. Use this for any totals instead of adding numbers yourself. "
        "ref is the result_ref shown in the tool message; list_path and field are dotted paths.",
        {"ref": {"type": "string"}, "list_path": {"type": "string", "description": "e.g. transaction_details"},
         "field": {"type": "string", "description": "e.g. transaction_info.transaction_amount.value (omit for count)"},
         "op": {"type": "string", "enum": ["sum", "count", "avg", "min", "max"]}},
        ["ref", "list_path", "op"]),
]
META_NAMES = {t["function"]["name"] for t in META_TOOLS}


def _dig(obj, path):
    for p in [x for x in path.split(".") if x]:
        obj = obj[p] if isinstance(obj, dict) else obj
    return obj


def aggregate(results: dict, ref, list_path, op, field=""):
    if ref not in results:
        return f"ERROR: unknown result_ref {ref}. Known: {', '.join(results) or 'none'}"
    try:
        rows = _dig(results[ref], list_path)
        if op == "count":
            return {"count": len(rows)}
        vals = [float(_dig(r, field)) for r in rows]
    except (KeyError, TypeError, ValueError) as e:
        return f"ERROR: could not read {list_path}/{field}: {e}"
    if not vals:
        return {op: 0, "n": 0}
    res = {"sum": sum(vals), "avg": sum(vals) / len(vals), "min": min(vals), "max": max(vals)}[op]
    return {op: round(res, 2), "n": len(vals)}
