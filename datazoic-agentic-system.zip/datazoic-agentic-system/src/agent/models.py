from dataclasses import dataclass, field, asdict


@dataclass
class ToolSpec:
    name: str
    service: str
    domain: str
    description: str
    method: str
    url_template: str          # e.g. {{base_url}}/v2/invoicing/invoices/:invoice_id
    params_schema: dict        # JSON schema for the *agent-facing* arguments
    path_params: list = field(default_factory=list)
    query_params: list = field(default_factory=list)
    body_keys: list = field(default_factory=list)
    risk: str = "read"         # read | write | sensitive (sensitive = needs human confirmation)
    example_queries: list = field(default_factory=list)

    def index_text(self) -> str:
        """What gets embedded / BM25'd. Deliberately richer than the raw Postman description."""
        ex = " ".join(self.example_queries)
        return f"{self.name.replace('_', ' ')} {self.service} {self.domain}. {self.description} Example requests: {ex}"

    def to_llm_tool(self) -> dict:
        """OpenAI-style function schema; langchain converts it for whichever provider is used."""
        desc = self.description
        if self.risk == "sensitive":
            desc += " (Sensitive: user will be asked to confirm.)"
        return {"type": "function",
                "function": {"name": self.name, "description": desc, "parameters": self.params_schema}}

    def to_dict(self):
        return asdict(self)
