# PayPal fees and limits (sample knowledge base)

## Standard transaction fees
Domestic card and PayPal-balance payments received by a business account cost a percentage of the amount plus a fixed fee per transaction. Cross-border payments and currency conversion add extra percentage fees. Fees are shown per transaction in the reporting API under fee_amount.

## Payout limits
Payouts (mass payments) accept up to 15000 items per batch. A single payout item can be sent to an email address, phone number or PayPal ID. New accounts may have lower daily sending limits until identity verification is complete.

## Refund policy
A merchant can refund a captured payment within 180 days of the original transaction. Partial refunds are allowed; the amount refunded cannot exceed the captured amount. The original processing fee is generally not returned on refund.
