"""LangGraph wiring. Loop: retrieve -> agent -> (execute -> retrieve -> agent)* -> END"""
import os
from datetime import date
from typing import Annotated, TypedDict

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.types import interrupt

from . import config, tools_exec
from .ingest import load_postman
from .meta_tools import META_TOOLS
from .rag import KnowledgeBase
from .registry import ToolRegistry
from .runlog import RunLog


def _merge(a, b):
    return {**(a or {}), **(b or {})}


def _extra(a, b):
    seen, out = set(), []
    for n in (a or []) + (b or []):
        if n not in seen:
            seen.add(n)
            out.append(n)
    return out[-8:]          # keep the last 8 discovered tools so follow-ups still work, but bounded


class AgentState(TypedDict):
    messages: Annotated[list, add_messages]
    bound: list                                   # tool names shown to the LLM this step
    extra_tools: Annotated[list, _extra]          # tools pulled in via search_tools
    results: Annotated[dict, _merge]              # result_ref -> full API response (by reference, not in prompt)
    steps: int


SYSTEM = """You are an assistant that operates a merchant's PayPal account through API tools. Today is {today}.
Rules:
- Use tools for anything about the account. Never invent ids, emails, or amounts; if a required value is missing, ask the user.
- You only see a few tools at a time. If none fits, call search_tools with a short description of the action.
- For how-to / policy / fee questions use rag_search. For 'what can you do' or 'what happened to my request' use system_search.
- For totals or counts over API results, use aggregate_result; never add numbers yourself.
- Some tools ask the user to confirm before running. Just call them; do not ask for confirmation yourself.
- The transactions API allows at most 31 days per call.
- Multi-step is fine (e.g. create a draft invoice, then send it). Keep the final answer short and state exactly what was done."""


def build_graph(llm=None, registry=None, kb=None, runlog=None, checkpointer=None):
    if registry is None:
        registry = ToolRegistry(load_postman(config.DATA / "paypal_collection.postman.json", config.DATA / "enrichment.json"))
    kb = kb or KnowledgeBase(config.DATA / "knowledge_base")
    runlog = runlog or RunLog()
    if llm is None:
        from langchain.chat_models import init_chat_model
        llm = init_chat_model(config.MODEL, temperature=0)

    def last_human(state, n=1):
        hs = [m.content for m in state["messages"] if isinstance(m, HumanMessage)]
        return " ".join(hs[-n:])

    def retrieve(state: AgentState):
        # two human turns of context so "yes, send it" still retrieves something sensible
        cands = registry.search(last_human(state, 2), k=config.TOP_K)
        names = [s.name for s in cands]
        for n in state.get("extra_tools", []):
            if n not in names and registry.get(n):
                names.append(n)
        return {"bound": names}

    def agent(state: AgentState):
        if state.get("steps", 0) >= config.MAX_STEPS:
            return {"messages": [AIMessage(content="I hit my step limit before finishing. Here is where I got to; "
                                                   "tell me how you'd like to continue.")]}
        tools = [registry.get(n).to_llm_tool() for n in state["bound"]] + META_TOOLS
        msg = llm.bind_tools(tools).invoke([SystemMessage(SYSTEM.format(today=date.today().isoformat()))] + state["messages"])
        return {"messages": [msg], "steps": state.get("steps", 0) + 1}

    def route(state: AgentState):
        return "execute" if getattr(state["messages"][-1], "tool_calls", None) else END

    def execute(state: AgentState, cfg: RunnableConfig):
        thread_id = cfg["configurable"]["thread_id"]
        calls = state["messages"][-1].tool_calls
        prepared = tools_exec.prepare(calls, set(state["bound"]), registry)
        # phase 1 has no side effects, so re-running this node after an interrupt is safe
        approvals = {}
        for p in prepared:
            if tools_exec.needs_confirmation(p):
                approvals[p["id"]] = bool(interrupt({"confirm": tools_exec.confirmation_text(p)}))
        ctx = dict(registry=registry, kb=kb, runlog=runlog, thread_id=thread_id,
                   user_msg=last_human(state), results=state.get("results", {}),
                   services=cfg["configurable"].get("services"))
        msgs, new_results, extra = tools_exec.execute(prepared, approvals, ctx)
        return {"messages": [ToolMessage(content=m["content"], tool_call_id=m["id"]) for m in msgs],
                "results": new_results, "extra_tools": extra}

    g = StateGraph(AgentState)
    g.add_node("retrieve", retrieve)
    g.add_node("agent", agent)
    g.add_node("execute", execute)
    g.add_edge(START, "retrieve")
    g.add_edge("retrieve", "agent")
    g.add_conditional_edges("agent", route, {"execute": "execute", END: END})
    g.add_edge("execute", "retrieve")
    return g.compile(checkpointer=checkpointer or MemorySaver())
