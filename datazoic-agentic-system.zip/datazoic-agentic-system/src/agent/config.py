import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data"

MODEL = os.getenv("AGENT_MODEL", "anthropic:claude-sonnet-5")   # any langchain init_chat_model string
TOP_K = int(os.getenv("TOP_K", "6"))                # candidate tools bound per step (tune with eval/run_eval.py)
HIERARCHICAL_THRESHOLD = int(os.getenv("HIER_THRESHOLD", "200"))  # go domain-first above this many tools
MAX_STEPS = int(os.getenv("MAX_STEPS", "8"))        # hard cap on agent<->tool loops per user turn
BACKEND_MODE = os.getenv("BACKEND_MODE", "mock")    # mock | sandbox
USE_EMBEDDINGS = os.getenv("USE_EMBEDDINGS", "0") == "1"
RUN_DB = os.getenv("RUN_DB", str(ROOT / "runs.sqlite"))
