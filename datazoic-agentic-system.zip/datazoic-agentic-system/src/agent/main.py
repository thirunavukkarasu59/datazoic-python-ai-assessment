"""Interactive CLI:  python -m src.agent.main
Set LANGSMITH_TRACING=true and LANGSMITH_API_KEY to get a trace per turn."""
import uuid

from langchain_core.messages import HumanMessage
from langgraph.types import Command

from .graph import build_graph


def main():
    graph = build_graph()
    thread = str(uuid.uuid4())[:8]
    cfg = {"configurable": {"thread_id": thread, "services": ["paypal"]},
           "tags": ["datazoic-demo"], "metadata": {"thread": thread}}
    print(f"thread {thread}. Ctrl-C to quit.")
    while True:
        text = input("\nyou> ").strip()
        if not text:
            continue
        out = graph.invoke({"messages": [HumanMessage(text)], "steps": 0}, cfg)
        while "__interrupt__" in out:                       # sensitive action waiting for a human
            ask = out["__interrupt__"][0].value["confirm"]
            ok = input(f"  confirm -> {ask}  [y/N] ").strip().lower() == "y"
            out = graph.invoke(Command(resume=ok), cfg)
        print("bot>", out["messages"][-1].content)


if __name__ == "__main__":
    main()
