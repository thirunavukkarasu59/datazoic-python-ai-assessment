"""Turns the LLM's tool_calls into results. No LangGraph imports on purpose: this is the part with
real logic (validation, permissions, retries, error shaping) and I want to unit-test it without an LLM.

Two phases so that a human-confirmation interrupt can safely re-run the node:
  prepare()  - classify + validate every call. No side effects.
  execute()  - actually run the approved calls.
"""
import json
import time

from . import backend, meta_tools
from .validation import validate_args

MAX_RESULT_CHARS = 1500


def prepare(tool_calls, bound, registry):
    out = []
    for c in tool_calls:
        name, args = c["name"], c.get("args") or {}
        p = {"id": c["id"], "name": name, "args": args, "kind": None, "spec": None, "error": None}
        if name in meta_tools.META_NAMES:
            p["kind"] = "meta"
        elif name not in bound or registry.get(name) is None:
            p["kind"], p["error"] = "error", (f"TOOL NOT AVAILABLE: '{name}' is not one of your current tools. "
                                              "Call search_tools to find the right one.")
        else:
            spec = registry.get(name)
            errs = validate_args(spec.params_schema, args)
            p["spec"] = spec
            if errs:
                p["kind"], p["error"] = "error", ("INVALID ARGUMENTS: " + "; ".join(errs) +
                                                  ". Fix them, or ask the user for missing values. Never invent values.")
            else:
                p["kind"] = "api"
        out.append(p)
    return out


def needs_confirmation(p):
    return p["kind"] == "api" and p["spec"].risk == "sensitive"


def confirmation_text(p):
    return f"{p['spec'].name} with {json.dumps(p['args'])}"


def _shape_result(data, results, new_results):
    ref = f"r{len(results) + len(new_results) + 1}"
    new_results[ref] = data
    text = json.dumps(data, default=str)
    if len(text) > MAX_RESULT_CHARS:
        text = text[:MAX_RESULT_CHARS] + f"... [truncated, {len(json.dumps(data, default=str))} chars total; use aggregate_result for totals]"
    return f"result_ref={ref} | {text}"


def _call_api(spec, args, thread_id, backoff):
    for attempt in range(3):
        try:
            return "ok", backend.run(spec, args, thread_id)
        except backend.ToolError as e:
            if e.retryable and attempt < 2:
                time.sleep(backoff * 2 ** attempt)
                continue
            if e.retryable:
                return "error", f"ERROR {e.status}: {e}. Still failing after 3 tries; tell the user the service is temporarily unavailable."
            return "error", f"ERROR {e.status}: {e}. Client error, so do not retry the same call; fix the arguments or explain to the user."
    return "error", "unreachable"


def execute(prepared, approvals, ctx, backoff=0.5):
    """approvals: {call_id: bool} for sensitive calls. ctx: registry, kb, runlog, thread_id, user_msg, results.
    Returns (tool_messages[{id,content}], new_results, new_extra_tools)."""
    msgs, new_results, extra = [], {}, []
    for p in prepared:
        name, args = p["name"], p["args"]
        if p["kind"] == "error":
            ctx["runlog"].record(ctx["thread_id"], ctx["user_msg"], name, args, "rejected", p["error"])
            msgs.append({"id": p["id"], "content": p["error"]})
        elif p["kind"] == "meta":
            content = _run_meta(name, args, ctx, new_results, extra)
            ctx["runlog"].record(ctx["thread_id"], ctx["user_msg"], name, args, "ok", "")
            msgs.append({"id": p["id"], "content": content})
        else:
            if needs_confirmation(p) and not approvals.get(p["id"], False):
                ctx["runlog"].record(ctx["thread_id"], ctx["user_msg"], name, args, "declined_by_user", "")
                msgs.append({"id": p["id"], "content": "USER DECLINED this action. Do not retry it; ask what they want instead."})
                continue
            status, data = _call_api(p["spec"], args, ctx["thread_id"], backoff)
            ctx["runlog"].record(ctx["thread_id"], ctx["user_msg"], name, args, status, "" if status == "ok" else data)
            msgs.append({"id": p["id"], "content": _shape_result(data, ctx["results"], new_results) if status == "ok" else data})
    return msgs, new_results, extra


def _run_meta(name, args, ctx, new_results, extra):
    reg = ctx["registry"]
    if name == "search_tools":
        found = reg.search(args.get("query", ""), k=5, services=ctx.get("services"))
        extra.extend(s.name for s in found)
        return "Now available to you: " + "; ".join(f"{s.name} ({s.description[:80]})" for s in found)
    if name == "rag_search":
        hits = ctx["kb"].search(args.get("query", ""), k=3)
        if not hits:
            return "No relevant passages found in the knowledge base."
        return "\n\n".join(f"[source: {h['source']} > {h['section']}]\n{h['text'][:700]}" for h in hits)
    if name == "system_search":
        if args.get("scope") == "runs":
            rows = ctx["runlog"].recent(ctx["thread_id"], limit=6)
            return json.dumps(rows) if rows else "No earlier requests recorded for this conversation."
        return json.dumps(reg.describe(args.get("query", ""), k=8))
    if name == "aggregate_result":
        merged = {**ctx["results"], **new_results}
        return json.dumps(meta_tools.aggregate(merged, args.get("ref"), args.get("list_path", ""), args.get("op"), args.get("field", "")))
    return f"unknown meta tool {name}"
