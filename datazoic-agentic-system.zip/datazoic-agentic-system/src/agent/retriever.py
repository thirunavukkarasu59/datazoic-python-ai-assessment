"""Hybrid retrieval: BM25 (pure python, so it runs anywhere) + optional dense embeddings,
fused with reciprocal rank fusion (RRF). Used for both the tool registry and the RAG tool."""
import math
import re
from collections import Counter

_STOP = set("a an the of to for and or in on at is are was be my me i you it this that with from by as do does did can could please".split())


def _stem(w: str) -> str:
    for suf in ("ing", "ed", "es", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            return w[: -len(suf)]
    return w


def tokenize(text: str):
    return [_stem(w) for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in _STOP]


class BM25:
    def __init__(self, docs_tokens, k1=1.5, b=0.75):
        self.docs = docs_tokens
        self.k1, self.b = k1, b
        self.N = len(docs_tokens)
        self.avgdl = (sum(len(d) for d in docs_tokens) / self.N) if self.N else 0
        df = Counter()
        for d in docs_tokens:
            df.update(set(d))
        self.idf = {t: math.log(1 + (self.N - n + 0.5) / (n + 0.5)) for t, n in df.items()}
        self.tf = [Counter(d) for d in docs_tokens]

    def scores(self, q_tokens):
        out = []
        for i, d in enumerate(self.docs):
            s, dl = 0.0, len(d)
            for t in q_tokens:
                f = self.tf[i].get(t, 0)
                if f:
                    s += self.idf[t] * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * dl / self.avgdl))
            out.append(s)
        return out


def make_embedder():
    """Returns fn(list[str]) -> np.ndarray or None. Only used if USE_EMBEDDINGS=1 and the lib is installed."""
    try:
        from sentence_transformers import SentenceTransformer
        m = SentenceTransformer("all-MiniLM-L6-v2")
        return lambda texts: m.encode(texts, normalize_embeddings=True)
    except Exception:
        return None


class HybridIndex:
    def __init__(self, texts, embedder=None):
        self.texts = texts
        self.bm25 = BM25([tokenize(t) for t in texts])
        self.embedder = embedder
        self.vecs = embedder(texts) if embedder else None

    def search(self, query, k=5, allowed=None):
        """Returns [(doc_index, score)] best first. `allowed` = set of doc indices to consider."""
        idx = [i for i in range(len(self.texts)) if allowed is None or i in allowed]
        bm = self.bm25.scores(tokenize(query))
        rankings = [sorted((i for i in idx if bm[i] > 0), key=lambda i: -bm[i])]
        if self.embedder is not None:
            qv = self.embedder([query])[0]
            sims = {i: float(self.vecs[i] @ qv) for i in idx}
            rankings.append(sorted(idx, key=lambda i: -sims[i]))
        fused = Counter()
        for r in rankings:
            for rank, i in enumerate(r):
                fused[i] += 1.0 / (60 + rank)
        return sorted(fused.items(), key=lambda x: -x[1])[:k]
