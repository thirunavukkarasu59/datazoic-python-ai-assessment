"""Validate LLM-produced arguments against the tool's JSON schema *before* anything is sent.
Uses `jsonschema` if installed, otherwise a small fallback that covers what ingest.py generates
(type / required / properties / items)."""

_TYPES = {"string": str, "boolean": bool, "object": dict, "array": list}


def _fallback(schema, value, path, errs):
    t = schema.get("type")
    if t == "integer":
        ok = isinstance(value, int) and not isinstance(value, bool)
    elif t == "number":
        ok = isinstance(value, (int, float)) and not isinstance(value, bool)
    elif t in _TYPES:
        ok = isinstance(value, _TYPES[t])
    else:
        ok = True
    if not ok:
        errs.append(f"{path or 'arguments'}: expected {t}, got {type(value).__name__}")
        return
    if t == "object":
        for r in schema.get("required", []):
            if r not in value:
                errs.append(f"{path + '.' if path else ''}{r}: required field is missing")
        for k, v in value.items():
            if k in schema.get("properties", {}):
                _fallback(schema["properties"][k], v, f"{path + '.' if path else ''}{k}", errs)
    if t == "array" and schema.get("items"):
        for i, v in enumerate(value):
            _fallback(schema["items"], v, f"{path}[{i}]", errs)


def validate_args(schema: dict, args: dict) -> list:
    """Returns a list of human-readable problems ([] = fine)."""
    errs = []
    unknown = [k for k in args if k not in schema.get("properties", {})]
    for k in unknown:
        errs.append(f"{k}: unknown parameter (allowed: {', '.join(schema.get('properties', {})) or 'none'})")
    try:
        import jsonschema
        v = jsonschema.Draft202012Validator(schema)
        errs += [f"{'.'.join(map(str, e.absolute_path)) or 'arguments'}: {e.message}" for e in v.iter_errors(args)]
    except ImportError:
        _fallback(schema, args, "", errs)
    return errs
