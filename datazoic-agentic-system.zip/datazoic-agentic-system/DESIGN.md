# Designing an agent that keeps working when it has hundreds of tools

## 1. The problem, and the one idea I'm building around

Give an LLM 10 tools and it mostly picks the right one. Give it 500 and it starts picking the wrong one, inventing parameters, or dithering. There are two causes, and they are different problems: the tool definitions eat the context (I measured ~120 tokens per PayPal endpoint, so 525 tools is about 63k tokens before the user has said anything), and the model has to discriminate between lookalike options, which it gets worse at as the list grows.

So my design rule is: **the model never sees the full tool list.** All tools live in a registry outside the prompt. On every step I retrieve a handful of candidates for what the user is asking and bind only those, plus four small always-on "meta" tools. In the prototype that is 6 candidates + 4 meta tools, about 1.2k tokens per step no matter whether the registry has 25 tools or 5,000. Everything else in this document is either how to make that retrieval good, or how to stop the agent hurting anyone when it acts on it.

I want to be upfront about the consequence: this moves the failure point. The LLM stops being the bottleneck and **retrieval quality** becomes the bottleneck. If the right tool isn't in the candidate set, no prompt can save the run. That's why I evaluate retrieval separately (section 9).

## 2. Architecture

```mermaid
flowchart LR
    U[User chat] --> R[retrieve<br/>top-k tools]
    REG[(Tool registry<br/>specs + index)] --> R
    R --> A[agent<br/>LLM with k tools + 4 meta tools]
    A -->|tool calls| X[execute]
    A -->|no tool call| END([answer])
    X -->|1 validate schema<br/>2 confirm if sensitive<br/>3 run + retry/idempotency| API[(PayPal / other APIs)]
    X --> RL[(run log)]
    X --> R
    A -.-> META[search_tools · rag_search · system_search · aggregate_result]
    CP[(checkpointer<br/>state per thread)] -.- A
```

It's one agent in a loop: `retrieve → agent → execute → retrieve → …` until the model answers without calling a tool. There is a step cap (8) so it can't loop forever.

Why one agent and not a crew of per-service agents? Because it's the simpler thing that works, and every extra agent is another place to lose context and another LLM hop of latency. I'd only split by service once services need different credentials, different safety rules, or different prompts. At that point I'd keep the same retrieval front-end and add a router that hands the request to a per-service agent. I'm not doing it now, and I'd want evidence it helps before I did.

## 3. Turning a Postman collection into something an LLM can use

This is the least glamorous part and probably the one that matters most. A raw Postman item gives you a method, a URL, an example body, and a description like "Creates a draft invoice." (`data/paypal_collection.postman.json` is deliberately written that way.) That's not enough for either retrieval or the model.

`ingest.py` does two things. It parses the collection into a `ToolSpec`: name, service, domain (from the Postman folder), path/query/body parameters, and a JSON schema inferred from the example values. Then it merges a sidecar (`data/enrichment.json`) that carries a proper description, which parameters are required, a risk level (`read` / `write` / `sensitive`), and 3 to 4 example user requests per tool. The example requests get indexed along with the description, which helps because users phrase things like "chase them up", not like API docs.

In a real deployment I'd generate the sidecar with an LLM pass over the collection and have a person review it once. `scripts/enrich_with_llm.py` has the prompt. I wrote the sidecar in this repo by hand, so it is better than what an automatic pass would produce on a first attempt. Treat the eval numbers below with that in mind.

One thing worth stating: unknown write endpoints default to `sensitive`. It's cheaper to ask one extra confirmation than to have a tool silently move money because nobody classified it.

## 4. Tool selection and routing

Retrieval is hybrid: BM25 plus (optionally) dense embeddings, combined with reciprocal rank fusion. BM25 alone is what the prototype runs by default, because it has no dependencies and works offline. Embeddings are one env var away (`USE_EMBEDDINGS=1`) but I haven't run them here, so I'm not claiming numbers for them.

Three mechanisms keep this working as the catalogue grows:

**Scoping before searching.** Most of the win at scale isn't smarter search, it's searching less. A user only has some services connected and only has permission for some tools. `search(..., services=..., allowed_names=...)` restricts the candidate pool first. In the stress test below this was the single biggest lever.

**Two-stage retrieval for big catalogues.** Above a threshold (200 tools, configurable), I first pick the 2 to 3 most likely (service, domain) groups — "PayPal / Disputes" — using a small group-level index, then search endpoints inside them. Two global hits are always mixed in as a safety net in case stage one picks the wrong domain. Below the threshold this path is off, because at 25 tools it's pure overhead (it produced identical results on my eval).

**An escape hatch.** The agent always has `search_tools("refund a payment")`. If the candidates look wrong, it asks again in its own words, and the tools it finds are bound on the next step (and kept for a few turns so "ok now send it" still works). This turns a retrieval miss from a dead end into one extra step. The agent can't call a tool that isn't currently bound; the executor rejects it and tells the model to use `search_tools`.

Retrieval also looks at the last two user messages, not one, so a short reply like "yes, send it" still retrieves something sensible.

## 5. Agent structure and state

State is a typed dict: the message list, the names of tools bound this step, tools discovered via `search_tools`, a `results` map, and a step counter. LangGraph's checkpointer persists it per `thread_id`, so a conversation can be resumed, and a human-confirmation pause can survive between two HTTP requests.

**Big API responses stay out of the prompt.** Every result is stored under a reference (`r3`) and the model sees a truncated preview plus the reference. This matters for the sales-volume question: the transactions API can return hundreds of rows, and an LLM adding 200 decimals in its head is a bug waiting to happen. So `aggregate_result(ref, list_path, field, op)` does the sum in code. The prototype keeps the full result inside the checkpointed state, which is fine for a demo; in production I'd push it to blob storage and keep only the reference in state.

Worked examples from the brief:

- *"Send an invoice for $50 to john@acme.com"* → retrieval surfaces `create_draft_invoice` and `send_invoice`. The model creates the draft, gets an invoice id back, then calls `send_invoice`. That second call is `sensitive` (it emails a customer), so the graph pauses and asks the human to confirm before it runs.
- *"What was my total sales volume last month?"* → `list_transactions` for last month's date range (the system prompt gives today's date, and the API's 31-day limit is called out), then `aggregate_result` to sum.
- *"Is there a dispute open from user_123?"* → the disputes API can't filter by buyer, and I wrote that into the tool description on purpose. The model lists open disputes and filters on `buyer.payer_id` itself. If I hadn't documented the limitation, the likely failure is the model inventing a `customer_id` query parameter, which validation would then reject as unknown.

## 6. The two extra tools

Both are ordinary tools from the agent's point of view, always bound, with no special-casing in the graph.

**`rag_search`** queries a knowledge base of docs, chunked by heading, and returns passages with their source file so the answer can cite them. Its description tells the model when *not* to use it (account data). In the prototype it reuses the same hybrid retriever over three small markdown files. In production I'd back it with LlamaIndex or pgvector; the tool interface doesn't change.

**`system_search`** has two scopes. `scope="tools"` searches the registry itself ("what can manage invoices?"). `scope="runs"` reads a small sqlite table of every tool call in the conversation with its status (`ok`, `error`, `rejected`, `declined_by_user`), so "what happened to my last request?" gets a factual answer. I kept the run log separate from the checkpointer on purpose: the checkpointer holds the full state, which is large and awkward to query, while the run log is a flat table anyone can `SELECT` from.

## 7. Error handling and safety

The useful move is treating failures differently by type, and telling the model in the error text what it should do next:

| Failure | What happens |
|---|---|
| Model calls a tool it wasn't given | Rejected, told to use `search_tools` |
| Bad or missing parameters | Schema validation before any request; error lists exactly what's wrong and says *don't invent values, ask the user* |
| 4xx from the API | Not retried. The message says it's a client error: fix the args or explain |
| 5xx / 429 | Exponential backoff, 3 tries, then tell the user the service is unavailable |
| Loop that never ends | Hard cap of 8 steps, then an honest "here's where I got stuck" |
| User says no to a confirmation | The call doesn't run; the model is told not to retry it |

For anything that moves money or contacts a customer there are two protections. A human confirmation (implemented with LangGraph `interrupt`) happens before execution, and every write carries an idempotency key hashed from the thread, tool and arguments, so a retry can't double-send. The confirmation step is split so that the part that pauses has no side effects: validation and approvals happen first, and only then do calls run. That matters because LangGraph re-runs a node from the top when it resumes after an interrupt, and I didn't want an earlier call in the same batch to execute twice.

## 8. Scaling from 25 to 500 to thousands

| Scale | What I'd do | Why |
|---|---|---|
| ~50 | Flat hybrid search, k≈6 | Two-stage retrieval measured no different at 25 tools |
| ~500 | Scope by connected services and permissions; two-stage retrieval; reranker if recall is short | Lookalike tools across services are the real problem |
| thousands | Vector DB (pgvector/Qdrant) with metadata filters, cached embeddings, per-tenant catalogues, tool-usage feedback in ranking, per-service agents only if needed | Index build and search stay cheap; the hard part is keeping descriptions good |

The stress test (`scripts/scale_test.py`) puts the 25 real tools next to 500 near-duplicates from 20 imaginary payment services, so every tool has a lookalike. That is a harsher setup than a real catalogue, where tools are more distinct, but it shows where things break:

| Setting (525 tools) | recall@6 | recall@10 |
|---|---|---|
| Flat, no scoping | 0.63 | 0.63 |
| Two-stage, no scoping | 0.77 | 0.93 |
| Flat + user's connected services | 0.93 | 1.00 |
| Two-stage + connected services | 0.97 | 1.00 |

Latency was under 1 ms per query for all of them (BM25 on 525 short documents), so at this size speed is not the issue. The takeaway I'd draw: scoping by what the user actually has connected beats any cleverness in the ranker. One caveat on the "flat, no scoping" row: the clones tie with the originals on score, and ties fall back to list order where the PayPal tools come first, so the true number for a real catalogue is probably lower.

## 9. Evaluation and observability

I'd measure two things separately, because they fail for different reasons:

1. **Retrieval recall@k**: is the correct tool in the candidate set? This is cheap, needs no LLM, and runs in CI (`eval/run_eval.py`).
2. **End-to-end success**: given a query, did the agent make the right calls with the right arguments? This needs an LLM and a mock backend, and is much noisier.

If the second drops and the first doesn't, it's a prompt/model problem. If both drop, it's the catalogue or the descriptions.

Current retrieval numbers on my 30-query set over the 25 PayPal tools (flat BM25):

| k | 1 | 3 | 5 | 6 | 8 |
|---|---|---|---|---|---|
| recall@k | 0.67 | 0.90 | 0.93 | 0.93 | 0.97 |

The two misses at k=6 are informative: "the customer hasn't paid, chase them up" (no lexical overlap with "reminder") and "show me all chargebacks I still have to respond to" ("chargeback" vs "dispute"). Those are exactly the cases embeddings should fix, and I can't say they will until I run it. **Caveat:** I wrote both the tool descriptions and the eval queries, so these numbers are optimistic. A real evaluation needs queries written by someone who hasn't read the descriptions, ideally taken from real chat logs.

For observability I'd use LangSmith. LangGraph traces every node automatically once `LANGSMITH_TRACING=true` is set, and because the candidate tool names are written into state (`bound`), each trace shows what the model was offered next to what it chose. That single view answers most debugging questions. Beyond that: log retrieval recall on real traffic (a run where the model calls `search_tools` right away is a retrieval miss), and track validation-rejection rate per tool, since a tool with a high rate usually has a bad description.

## 10. Framework choice

I chose **LangGraph**, with LangChain only for the model wrapper.

| Option | Where I landed |
|---|---|
| **LangGraph** (chosen) | Explicit graph, built-in checkpointing, `interrupt` for human approval, first-class LangSmith tracing. Those are exactly the four things this design leans on. Cost: more boilerplate, and its API moves quickly. |
| CrewAI | Quick for role-based multi-agent demos, but I'd have less control over per-step tool binding and retries, which is the core of this design. |
| LlamaIndex | Strong for the RAG tool, and I'd use it there in production. As the orchestrator it's less natural for this shape of loop. |
| DSPy | Interesting *after* I have an eval set: it could optimise the tool-selection prompt against recall. It isn't an orchestrator. |
| From scratch | Fewest dependencies and full control, and the loop itself is about 50 lines. But I'd end up rebuilding checkpointing, interrupts and tracing. I'd only go this way if the framework became the bottleneck. |

I kept the parts with real logic (validation, retries, permissions, result shaping in `tools_exec.py`; retrieval in `registry.py`) free of LangGraph imports. That is partly so I can unit-test them without an LLM, and partly so that if I do drop LangGraph one day, only `graph.py` changes.

## 11. What's built, what isn't, and what I'm unsure about

**Tested here (20 unit tests, offline):** ingestion, retrieval, hierarchical retrieval, schema validation, the executor (unbound tools, invalid args, declined confirmations, idempotent retries, 4xx vs 5xx handling, the multi-step invoice flow), the RAG and system-search tools, and aggregation.

**Written but not run:** `graph.py` and `main.py`. The build environment had no LangGraph and no network, so I could only check that they compile. Expect to fix small API mismatches on first run. `backend._http` (real PayPal sandbox calls) is also untested.

**Not built:** a reranker, embeddings runs, a real end-to-end LLM eval, message-history trimming for long conversations (the history is unbounded right now), and auth per user. The sample collection has 25 endpoints, not 50+; adding the rest is data work rather than design work, and the 525-tool stress test is my stand-in for it.

**Things I'm unsure about:** the right value of k. I picked 6 because recall stopped improving much after it on this set, but I'd want to tune it with a real LLM in the loop, since a larger k costs tokens and raises confusion. I'm also not sure two-stage retrieval earns its complexity on a catalogue that's mostly distinct tools; the stress test says it helps for lookalikes, but that test is deliberately adversarial.
