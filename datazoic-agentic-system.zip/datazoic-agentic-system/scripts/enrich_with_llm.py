"""Sketch of the enrichment pass that produces data/enrichment.json from a raw Postman collection.
NOT RUN in this repo: data/enrichment.json was written by hand. Shown so the ingestion story is complete.

For each Postman item, ask an LLM for the four things Postman does not give us, then have a human skim the diff once.
"""
PROMPT = """You are documenting an API endpoint for an AI agent that must choose between hundreds of endpoints.

Endpoint: {method} {url}
Folder: {folder}
Name: {name}
Original description: {description}
Example body: {body}

Return JSON with:
- description: 1-2 sentences. Say what it does, when to use it, what it needs from other calls
  (e.g. 'needs invoice_id from create_draft_invoice'), and any limits that change how the agent must behave
  (e.g. 'cannot filter by customer').
- example_queries: 4 different ways a business user might ask for this in chat. Use everyday words, not API words.
- required: names of parameters that must be provided.
- risk: 'read' | 'write' | 'sensitive'. Use 'sensitive' if it moves money, contacts a third party, or cannot be undone.
"""

if __name__ == "__main__":
    print(PROMPT)
