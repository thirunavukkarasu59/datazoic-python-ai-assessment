# Invoicing guide (sample knowledge base)

## Invoice statuses
An invoice moves DRAFT, SENT, PARTIALLY_PAID, PAID. Sent invoices that are unpaid can be cancelled or reminded. A draft invoice is never visible to the customer until it is sent.

## Invoice numbers
Invoice numbers are generated automatically unless a custom number is provided. Numbers must be unique per merchant account.

## Currencies
An invoice has a single currency. Line items, tax and discounts all use that currency. To bill in another currency create a separate invoice.
