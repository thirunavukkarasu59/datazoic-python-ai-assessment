# Scalable agentic system: tool retrieval in front of a small LangGraph loop

Take-home for Datazoic. **Start with [DESIGN.md](DESIGN.md)**, which is the actual answer to the task. This repo is the working prototype behind it.

One-line summary: the LLM never sees all the tools. They live in a registry; each step retrieves ~6 candidates and binds only those, plus four always-on tools (`search_tools`, `rag_search`, `system_search`, `aggregate_result`).

## What's in here

```
DESIGN.md                    the design write-up (architecture, trade-offs, numbers, limitations)
data/
  paypal_collection.postman.json   25-endpoint sample of a PayPal Postman collection (terse descriptions, like the real thing)
  enrichment.json                  better descriptions, example queries, required params, risk levels
  knowledge_base/*.md              tiny docs for the RAG tool
src/agent/
  ingest.py        Postman -> ToolSpec (+ JSON schema)
  retriever.py     BM25 + optional embeddings, fused with RRF
  registry.py      tool registry: scoped search, two-stage search for big catalogues
  tools_exec.py    validation, confirmation, retries, error shaping (no LangGraph imports)
  backend.py       mock PayPal API (default) + untested sandbox HTTP client
  meta_tools.py    search_tools / rag_search / system_search / aggregate_result
  rag.py, runlog.py, validation.py, models.py, config.py
  graph.py         LangGraph wiring          <- NOT run in the build environment, see below
  main.py          CLI chat loop             <- same
eval/              30-query retrieval eval set + runner
scripts/           500-tool stress test, LLM enrichment prompt (sketch)
tests/             20 offline unit tests
```

## Run the parts that need no API key

Only Python 3.10+ is required (no packages).

```bash
python3 -m unittest discover -s tests -v     # 20 tests
python3 eval/run_eval.py                     # retrieval recall@k on the 25 PayPal tools
python3 scripts/scale_test.py                # 525-tool stress test
```

## Run the actual agent (needs an LLM key)

```bash
python3 -m venv .venv && source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                      # then fill in the key(s); export them or use a dotenv loader
export $(grep -v '^#' .env | xargs)                       # Windows: set the variables manually
python3 -m src.agent.main
```

Try: `Send an invoice for $50 to john@acme.com`, then `What was my total sales volume last month?`, `Is there a dispute open from user_123?`, `What tools can manage invoices?`, `How long do I have to refund a payment?`, `What happened to my last request?`.
Sensitive actions (sending an invoice, payouts, refunds) stop and ask `[y/N]` first. It runs against a mock PayPal by default (`BACKEND_MODE=mock`). With `LANGSMITH_TRACING=true` and a key, every turn shows up as a trace.

## Honest status

- Tested (offline): everything except the two items below.
- **`graph.py` / `main.py` compile but were never executed**: the build environment had no LangGraph and no network. Expect small API fixes on first run (LangGraph's interrupt/resume API changes between versions).
- `backend._http` (real PayPal sandbox) is untested.
- Eval numbers in DESIGN.md are optimistic: I wrote the descriptions and the queries. See the caveats there.
