"""RAG tool: chunk markdown docs by heading, index with the same hybrid retriever, return passages + source.
Swap KnowledgeBase for a LlamaIndex / pgvector retriever in production; the tool interface stays the same."""
import re
from pathlib import Path

from .retriever import HybridIndex


class KnowledgeBase:
    def __init__(self, folder, embedder=None):
        self.chunks = []
        for f in sorted(Path(folder).glob("*.md")):
            text = f.read_text()
            for part in re.split(r"\n(?=#{1,3} )", text):
                part = part.strip()
                if len(part) > 40:
                    title = part.splitlines()[0].lstrip("# ").strip()
                    self.chunks.append({"source": f.name, "section": title, "text": part})
        self.index = HybridIndex([c["section"] + " " + c["text"] for c in self.chunks], embedder)

    def search(self, query, k=3):
        return [{**self.chunks[i], "score": round(s, 4)} for i, s in self.index.search(query, k=k)]
