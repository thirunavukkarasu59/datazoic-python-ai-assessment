from collections import defaultdict

from . import config
from .retriever import HybridIndex, make_embedder


class ToolRegistry:
    """All tools live here, never in the prompt. The agent only ever sees `search()` results."""

    def __init__(self, specs, embedder=None):
        self.specs = list(specs)
        self.by_name = {s.name: s for s in self.specs}
        if embedder is None and config.USE_EMBEDDINGS:
            embedder = make_embedder()
        self.index = HybridIndex([s.index_text() for s in self.specs], embedder)
        # domain-level index for the hierarchical path: one doc per (service, domain)
        groups = defaultdict(list)
        for i, s in enumerate(self.specs):
            groups[(s.service, s.domain)].append(i)
        self.group_keys = list(groups)
        self.group_members = [set(groups[g]) for g in self.group_keys]
        self.group_index = HybridIndex(
            [" ".join(f"{self.specs[i].name.replace('_',' ')} {self.specs[i].service} {self.specs[i].domain} "
                      + " ".join(self.specs[i].example_queries) for i in groups[g]) for g in self.group_keys],
            embedder,
        )

    def _allowed(self, services=None, names=None):
        if services is None and names is None:
            return None
        return {i for i, s in enumerate(self.specs)
                if (services is None or s.service in services) and (names is None or s.name in names)}

    def search(self, query, k=None, services=None, allowed_names=None, hierarchical=None):
        """services = which services this user has connected; allowed_names = per-tenant permissions."""
        k = k or config.TOP_K
        allowed = self._allowed(services, allowed_names)
        if hierarchical is None:
            hierarchical = len(self.specs) > config.HIERARCHICAL_THRESHOLD
        hits = []
        if hierarchical:
            # stage 1: pick the 2-3 most likely (service, domain) groups
            groups = self.group_index.search(query, k=3)
            scoped = set().union(*(self.group_members[g] for g, _ in groups)) if groups else set()
            if allowed is not None:
                scoped &= allowed
            hits = self.index.search(query, k=max(k - 2, 1), allowed=scoped)
            # stage 2 safety net: up to 2 global hits in case stage 1 picked the wrong domain (total stays <= k)
            seen = {i for i, _ in hits}
            for i, sc in self.index.search(query, k=k, allowed=allowed):
                if i not in seen and len(hits) < k:
                    hits.append((i, sc))
        else:
            hits = self.index.search(query, k=k, allowed=allowed)
        return [self.specs[i] for i, _ in hits]

    def get(self, name):
        return self.by_name.get(name)

    def describe(self, query, k=8):
        """Human-facing catalogue lookup, used by the system_search tool."""
        return [{"name": s.name, "service": s.service, "domain": s.domain,
                 "risk": s.risk, "description": s.description[:140]}
                for s in self.search(query, k=k, hierarchical=False)]
