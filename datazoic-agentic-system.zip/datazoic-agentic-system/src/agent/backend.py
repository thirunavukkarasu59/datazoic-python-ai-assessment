"""Executes a ToolSpec with validated args.

mock    : deterministic in-memory fake of the PayPal API (default; lets the whole thing run offline)
sandbox : real HTTP call against PayPal sandbox using OAuth client-credentials. Written but NOT tested
          in this repo (I had no sandbox credentials while building it).
"""
import hashlib
import json
import os
import random
import re
from datetime import datetime, timedelta, timezone

from . import config

_STORE = {"invoices": {}, "orders": {}, "payouts": {}}
_IDEMP = {}   # request-id -> response, so a retried write does not run twice


def _fill_url(spec, args):
    url = spec.url_template.replace("{{base_url}}", os.getenv("PAYPAL_BASE_URL", "https://api-m.sandbox.paypal.com"))
    for p in spec.path_params:
        url = url.replace(f":{p}", str(args[p]))
    return url


def idempotency_key(thread_id, tool, args):
    return hashlib.sha256(f"{thread_id}|{tool}|{json.dumps(args, sort_keys=True)}".encode()).hexdigest()[:32]


class ToolError(Exception):
    def __init__(self, status, message, retryable=False):
        super().__init__(message)
        self.status, self.retryable = status, retryable


def run(spec, args, thread_id="t0"):
    key = idempotency_key(thread_id, spec.name, args) if spec.risk != "read" else None
    if key and key in _IDEMP:
        return _IDEMP[key]
    out = _mock(spec, args) if config.BACKEND_MODE == "mock" else _http(spec, args, key)
    if key:
        _IDEMP[key] = out
    return out


# ---------------------------------------------------------------- sandbox (untested)
def _http(spec, args, key):
    import httpx
    base = os.getenv("PAYPAL_BASE_URL", "https://api-m.sandbox.paypal.com")
    tok = httpx.post(f"{base}/v1/oauth2/token", data={"grant_type": "client_credentials"},
                     auth=(os.environ["PAYPAL_CLIENT_ID"], os.environ["PAYPAL_CLIENT_SECRET"]), timeout=15).json()["access_token"]
    headers = {"Authorization": f"Bearer {tok}", "Content-Type": "application/json"}
    if key:
        headers["PayPal-Request-Id"] = key
    r = httpx.request(spec.method, _fill_url(spec, args),
                      params={k: args[k] for k in spec.query_params if k in args and args[k] != ""},
                      json={k: args[k] for k in spec.body_keys if k in args} or None,
                      headers=headers, timeout=30)
    if r.status_code >= 500 or r.status_code == 429:
        raise ToolError(r.status_code, r.text[:200], retryable=True)
    if r.status_code >= 400:
        raise ToolError(r.status_code, r.text[:400])
    return r.json() if r.text else {"status": "ok"}


# ---------------------------------------------------------------- mock
def _txns():
    rnd = random.Random(42)                      # deterministic
    now = datetime.now(timezone.utc)
    out = []
    for i in range(90):
        d = now - timedelta(days=rnd.randint(0, 75), hours=rnd.randint(0, 23))
        out.append({"transaction_info": {
            "transaction_id": f"TX{1000 + i}", "transaction_initiation_date": d.strftime("%Y-%m-%dT%H:%M:%S+0000"),
            "transaction_amount": {"currency_code": "USD", "value": f"{rnd.randint(500, 25000) / 100:.2f}"},
            "transaction_status": "S"}})
    return out


_DISPUTES = [
    {"dispute_id": "PP-D-27803", "status": "OPEN", "reason": "MERCHANDISE_OR_SERVICE_NOT_RECEIVED",
     "dispute_amount": {"currency_code": "USD", "value": "42.00"},
     "disputed_transactions": [{"seller_transaction_id": "TX1004", "buyer": {"payer_id": "user_123", "name": "Asha K"}}]},
    {"dispute_id": "PP-D-27811", "status": "RESOLVED", "reason": "UNAUTHORISED",
     "dispute_amount": {"currency_code": "USD", "value": "15.00"},
     "disputed_transactions": [{"seller_transaction_id": "TX1010", "buyer": {"payer_id": "user_456", "name": "Ravi S"}}]},
    {"dispute_id": "PP-D-27820", "status": "OPEN", "reason": "ITEM_NOT_AS_DESCRIBED",
     "dispute_amount": {"currency_code": "USD", "value": "99.00"},
     "disputed_transactions": [{"seller_transaction_id": "TX1022", "buyer": {"payer_id": "user_789", "name": "Meera P"}}]},
]


def _mock(spec, a):
    n = spec.name
    if n == "create_draft_invoice":
        iid = f"INV2-{len(_STORE['invoices']) + 1:04d}"
        _STORE["invoices"][iid] = {"id": iid, "status": "DRAFT", **{k: a[k] for k in a}}
        return {"id": iid, "status": "DRAFT", "href": f"/v2/invoicing/invoices/{iid}"}
    if n in ("send_invoice", "cancel_invoice", "send_invoice_reminder", "get_invoice_details"):
        inv = _STORE["invoices"].get(a["invoice_id"])
        if not inv:
            raise ToolError(404, f"Invoice {a['invoice_id']} not found (RESOURCE_NOT_FOUND)")
        if n == "send_invoice":
            inv["status"] = "SENT"
        if n == "cancel_invoice":
            inv["status"] = "CANCELLED"
        return {"id": inv["id"], "status": inv["status"]}
    if n == "list_invoices":
        items = list(_STORE["invoices"].values())
        return {"total_items": len(items), "items": items}
    if n == "create_order":
        oid = f"ORD{len(_STORE['orders']) + 1:05d}"
        _STORE["orders"][oid] = {"id": oid, "status": "CREATED"}
        return _STORE["orders"][oid]
    if n in ("capture_order_payment", "get_order_details"):
        o = _STORE["orders"].get(a["order_id"])
        if not o:
            raise ToolError(404, "Order not found")
        return o
    if n == "refund_captured_payment":
        return {"id": "REF-1", "status": "COMPLETED", "capture_id": a["capture_id"]}
    if n == "send_payout":
        bid = f"PAYOUT-{len(_STORE['payouts']) + 1:04d}"
        _STORE["payouts"][bid] = {"batch_status": "SUCCESS", "id": bid}
        return {"batch_header": {"payout_batch_id": bid, "batch_status": "PENDING"}}
    if n == "get_payout_batch_status":
        return _STORE["payouts"].get(a["payout_batch_id"]) or (_ for _ in ()).throw(ToolError(404, "Batch not found"))
    if n == "list_disputes":
        ds = _DISPUTES
        if a.get("dispute_state") in ("OPEN_INQUIRIES", "OPEN"):
            ds = [d for d in ds if d["status"] == "OPEN"]
        if a.get("disputed_transaction_id"):
            ds = [d for d in ds if d["disputed_transactions"][0]["seller_transaction_id"] == a["disputed_transaction_id"]]
        return {"items": ds}
    if n == "get_dispute_details":
        for d in _DISPUTES:
            if d["dispute_id"] == a["dispute_id"]:
                return d
        raise ToolError(404, "Dispute not found")
    if n in ("accept_dispute_claim", "provide_dispute_evidence", "escalate_dispute_to_claim"):
        return {"dispute_id": a["dispute_id"], "status": "UNDER_REVIEW"}
    if n == "list_transactions":
        def p(s):
            return datetime.strptime(re.sub(r"(Z|[+-]0000)$", "", s)[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc)
        lo, hi = p(a["start_date"]), p(a["end_date"])
        if (hi - lo).days > 31:
            raise ToolError(400, "Date range too large: maximum is 31 days (DATE_RANGE_TOO_LARGE)")
        rows = [t for t in _txns() if lo <= p(t["transaction_info"]["transaction_initiation_date"]) <= hi]
        return {"transaction_details": rows, "total_items": len(rows), "page": 1, "total_pages": 1}
    if n == "get_balances":
        return {"balances": [{"currency": a.get("currency_code", "USD"), "total_balance": {"value": "1843.20"}}]}
    if n == "list_subscription_plans":
        return {"plans": [{"id": "P-MONTHLY", "name": "Monthly"}, {"id": "P-YEARLY", "name": "Yearly"}]}
    if n in ("get_subscription_details", "cancel_subscription", "create_subscription"):
        return {"id": a.get("subscription_id", "I-NEW"), "status": "CANCELLED" if n == "cancel_subscription" else "ACTIVE"}
    if n == "list_webhooks":
        return {"webhooks": [{"id": "WH-1", "url": "https://example.com/hook", "event_types": ["PAYMENT.CAPTURE.COMPLETED"]}]}
    if n == "get_user_info":
        return {"name": "Demo Merchant", "email": "merchant@example.com", "payer_id": "MERCHANT1"}
    return {"status": "ok", "mock": True}
