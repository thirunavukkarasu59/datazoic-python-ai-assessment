"""Offline tests (no LLM, no network).  python -m unittest discover -s tests -v"""
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from agent import backend, config, meta_tools, tools_exec       # noqa: E402
from agent.ingest import load_postman                           # noqa: E402
from agent.rag import KnowledgeBase                             # noqa: E402
from agent.registry import ToolRegistry                         # noqa: E402
from agent.runlog import RunLog                                 # noqa: E402
from agent.validation import validate_args                      # noqa: E402

SPECS = load_postman(ROOT / "data/paypal_collection.postman.json", ROOT / "data/enrichment.json")
REG = ToolRegistry(SPECS)
KB = KnowledgeBase(ROOT / "data/knowledge_base")


def ctx(tmp, results=None):
    return dict(registry=REG, kb=KB, runlog=RunLog(os.path.join(tmp, "r.sqlite")), thread_id="t1",
                user_msg="test", results=results or {})


def call(name, args, cid="c1"):
    return {"id": cid, "name": name, "args": args}


class Ingest(unittest.TestCase):
    def test_loads_all_and_schemas(self):
        self.assertEqual(len(SPECS), 25)
        s = REG.get("send_invoice")
        self.assertEqual(s.path_params, ["invoice_id"])
        self.assertIn("invoice_id", s.params_schema["required"])
        self.assertEqual(s.risk, "sensitive")

    def test_query_int_inferred(self):
        self.assertEqual(REG.get("list_invoices").params_schema["properties"]["page_size"]["type"], "integer")


class Retrieval(unittest.TestCase):
    def test_brief_examples(self):
        self.assertIn("create_draft_invoice", [s.name for s in REG.search("Send an invoice for $50 to john@acme.com", k=4)])
        self.assertIn("list_transactions", [s.name for s in REG.search("What was my total sales volume last month?", k=4)])
        self.assertIn("list_disputes", [s.name for s in REG.search("Is there a dispute open from user_123?", k=4)])

    def test_service_scoping_excludes_others(self):
        self.assertEqual(REG.search("invoice", k=5, services={"nope"}), [])


class Validation(unittest.TestCase):
    def test_missing_required(self):
        errs = validate_args(REG.get("send_invoice").params_schema, {})
        self.assertTrue(any("invoice_id" in e for e in errs))

    def test_unknown_param_and_type(self):
        errs = validate_args(REG.get("list_invoices").params_schema, {"page_size": "ten", "bogus": 1})
        self.assertTrue(any("bogus" in e for e in errs))

    def test_valid(self):
        self.assertEqual(validate_args(REG.get("get_invoice_details").params_schema, {"invoice_id": "X"}), [])


class Execution(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def run_calls(self, calls, bound, approvals=None, results=None):
        prep = tools_exec.prepare(calls, set(bound), REG)
        return tools_exec.execute(prep, approvals or {}, ctx(self.tmp, results), backoff=0)

    def test_unbound_tool_rejected(self):
        msgs, _, _ = self.run_calls([call("cancel_subscription", {"subscription_id": "I-1", "reason": "x"})], ["list_invoices"])
        self.assertIn("TOOL NOT AVAILABLE", msgs[0]["content"])

    def test_invalid_args_reported_not_executed(self):
        msgs, _, _ = self.run_calls([call("send_invoice", {})], ["send_invoice"])
        self.assertIn("INVALID ARGUMENTS", msgs[0]["content"])

    def test_sensitive_declined_does_not_run(self):
        args = {"sender_batch_header": {"sender_batch_id": "b", "email_subject": "s"}, "items": []}
        msgs, res, _ = self.run_calls([call("send_payout", args)], ["send_payout"], approvals={"c1": False})
        self.assertIn("DECLINED", msgs[0]["content"])
        self.assertEqual(res, {})

    def test_multistep_invoice_flow_and_idempotency(self):
        args = {"detail": {"currency_code": "USD"}, "primary_recipients": [{"billing_info": {"email_address": "a@b.co"}}],
                "items": [{"name": "x", "quantity": "1", "unit_amount": {"currency_code": "USD", "value": "50.00"}}]}
        m1, r1, _ = self.run_calls([call("create_draft_invoice", args)], ["create_draft_invoice"])
        self.assertIn("DRAFT", m1[0]["content"])
        n_before = len(backend._STORE["invoices"])
        self.run_calls([call("create_draft_invoice", args)], ["create_draft_invoice"])   # identical retry
        self.assertEqual(len(backend._STORE["invoices"]), n_before)                      # no duplicate invoice
        iid = list(backend._STORE["invoices"])[-1]
        m2, _, _ = self.run_calls([call("send_invoice", {"invoice_id": iid})], ["send_invoice"], approvals={"c1": True})
        self.assertIn("SENT", m2[0]["content"])

    def test_client_error_is_not_retried_and_explained(self):
        msgs, _, _ = self.run_calls([call("get_invoice_details", {"invoice_id": "NOPE"})], ["get_invoice_details"])
        self.assertIn("ERROR 404", msgs[0]["content"])
        self.assertIn("do not retry", msgs[0]["content"])

    def test_date_range_error_from_api(self):
        a = {"start_date": "2026-01-01T00:00:00-0000", "end_date": "2026-08-01T00:00:00-0000"}
        msgs, _, _ = self.run_calls([call("list_transactions", a)], ["list_transactions"])
        self.assertIn("31 days", msgs[0]["content"])

    def test_retryable_error_retried_then_reported(self):
        orig, calls = backend.run, []

        def flaky(spec, args, thread_id="t"):
            calls.append(1)
            raise backend.ToolError(503, "upstream down", retryable=True)
        backend.run = flaky
        try:
            msgs, _, _ = self.run_calls([call("get_balances", {})], ["get_balances"])
        finally:
            backend.run = orig
        self.assertEqual(len(calls), 3)
        self.assertIn("temporarily unavailable", msgs[0]["content"])

    def test_sales_volume_uses_aggregate_by_reference(self):
        import datetime as dt
        now = dt.datetime.now(dt.timezone.utc)
        a = {"start_date": (now - dt.timedelta(days=30)).strftime("%Y-%m-%dT%H:%M:%S-0000"),
             "end_date": now.strftime("%Y-%m-%dT%H:%M:%S-0000")}
        msgs, res, _ = self.run_calls([call("list_transactions", a)], ["list_transactions"])
        ref = msgs[0]["content"].split("|")[0].split("=")[1].strip()
        agg, _, _ = self.run_calls([call("aggregate_result", {"ref": ref, "list_path": "transaction_details", "op": "sum",
                                    "field": "transaction_info.transaction_amount.value"}, "c2")], [], results=res)
        self.assertIn('"sum"', agg[0]["content"])

    def test_dispute_by_customer_needs_client_side_filter(self):
        msgs, res, _ = self.run_calls([call("list_disputes", {"dispute_state": "OPEN_INQUIRIES"})], ["list_disputes"])
        self.assertIn("user_123", str(list(res.values())[0]))


class MetaTools(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def test_search_tools_adds_extra(self):
        prep = tools_exec.prepare([call("search_tools", {"query": "refund a payment"})], set(), REG)
        _, _, extra = tools_exec.execute(prep, {}, ctx(self.tmp))
        self.assertIn("refund_captured_payment", extra)

    def test_rag_returns_source(self):
        prep = tools_exec.prepare([call("rag_search", {"query": "how long do I have to refund"})], set(), REG)
        msgs, _, _ = tools_exec.execute(prep, {}, ctx(self.tmp))
        self.assertIn("paypal_fees_and_limits.md", msgs[0]["content"])

    def test_system_search_tools_and_runs(self):
        c = ctx(self.tmp)
        prep = tools_exec.prepare([call("system_search", {"scope": "tools", "query": "manage invoices"})], set(), REG)
        msgs, _, _ = tools_exec.execute(prep, {}, c)
        self.assertIn("invoice", msgs[0]["content"])
        prep = tools_exec.prepare([call("get_balances", {}, "c9")], {"get_balances"}, REG)
        tools_exec.execute(prep, {}, c)
        prep = tools_exec.prepare([call("system_search", {"scope": "runs"}, "c10")], set(), REG)
        msgs, _, _ = tools_exec.execute(prep, {}, c)
        self.assertIn("get_balances", msgs[0]["content"])

    def test_aggregate_unknown_ref(self):
        self.assertIn("unknown result_ref", meta_tools.aggregate({}, "r9", "x", "sum", "y"))


if __name__ == "__main__":
    unittest.main()
