"""Tiny sqlite log of every tool call. This is what the system_search tool reads when the user asks
"what happened to my last request?". LangGraph's checkpointer holds the full state; this is the cheap,
queryable summary."""
import json
import sqlite3
import time

from . import config


class RunLog:
    def __init__(self, path=None):
        self.db = sqlite3.connect(path or config.RUN_DB, check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS calls(
            id INTEGER PRIMARY KEY, ts REAL, thread_id TEXT, user_msg TEXT,
            tool TEXT, args TEXT, status TEXT, detail TEXT)""")
        self.db.commit()

    def record(self, thread_id, user_msg, tool, args, status, detail=""):
        self.db.execute("INSERT INTO calls(ts,thread_id,user_msg,tool,args,status,detail) VALUES(?,?,?,?,?,?,?)",
                        (time.time(), thread_id, user_msg[:300], tool, json.dumps(args)[:500], status, str(detail)[:300]))
        self.db.commit()

    def recent(self, thread_id, limit=5):
        rows = self.db.execute(
            "SELECT ts,user_msg,tool,args,status,detail FROM calls WHERE thread_id=? ORDER BY id DESC LIMIT ?",
            (thread_id, limit)).fetchall()
        return [{"when": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(r[0])), "request": r[1],
                 "tool": r[2], "args": json.loads(r[3]), "status": r[4], "detail": r[5]} for r in rows]
