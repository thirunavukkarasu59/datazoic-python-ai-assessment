"""Scalable tool-using agent: registry + retrieval in front of a small LangGraph loop."""
