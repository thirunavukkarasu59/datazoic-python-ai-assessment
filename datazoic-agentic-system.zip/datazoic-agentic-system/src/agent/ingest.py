"""Postman collection -> list[ToolSpec].

Postman gives us method, URL, example params and a (usually useless) description.
The enrichment sidecar (data/enrichment.json) adds a proper description, example user
queries, which params are required, and a risk level. In a real deployment that sidecar
is produced by an LLM pass over the collection and then reviewed by a human once;
see scripts/enrich_with_llm.py for the prompt I would use.
"""
import json
import re
from pathlib import Path

from .models import ToolSpec


def slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")


def infer_schema(v):
    if isinstance(v, bool):
        return {"type": "boolean"}
    if isinstance(v, int):
        return {"type": "integer"}
    if isinstance(v, float):
        return {"type": "number"}
    if isinstance(v, list):
        return {"type": "array", "items": infer_schema(v[0]) if v else {}}
    if isinstance(v, dict):
        return {"type": "object", "properties": {k: infer_schema(x) for k, x in v.items()}}
    return {"type": "string"}


def _query_schema(value: str, key: str):
    if value in ("true", "false"):
        return {"type": "boolean"}
    if re.fullmatch(r"\d+", value or ""):
        return {"type": "integer"}
    return {"type": "string"}


def _walk(items, folder=""):
    for it in items:
        if "item" in it:
            yield from _walk(it["item"], it["name"])
        else:
            yield folder, it


def load_postman(path, enrichment_path=None) -> list:
    coll = json.loads(Path(path).read_text())
    enrich = {}
    if enrichment_path and Path(enrichment_path).exists():
        enrich = json.loads(Path(enrichment_path).read_text())
    service = slug(coll["info"]["name"])
    specs, seen = [], set()

    for folder, it in _walk(coll["item"]):
        name = slug(it["name"])
        if name in seen:
            raise ValueError(f"duplicate tool name {name}; rename the Postman item")
        seen.add(name)
        req = it["request"]
        url = req["url"]
        e = enrich.get(name, {})

        path_params = [p[1:] for p in url.get("path", []) if p.startswith(":")]
        props, path_p, query_p, body_k = {}, [], [], []
        for p in path_params:
            props[p] = {"type": "string", "description": f"{p} (path parameter)"}
            path_p.append(p)
        for q in url.get("query", []):
            s = _query_schema(q.get("value", ""), q["key"])
            ex = q.get("value")
            s["description"] = (q.get("description") or "") + (f" e.g. {ex}" if ex else "")
            props[q["key"]] = s
            query_p.append(q["key"])
        body = req.get("body")
        if body and body.get("mode") == "raw":
            example = json.loads(body["raw"])
            for k, v in example.items():
                s = infer_schema(v)
                s["description"] = "body field"
                props[k] = s
                body_k.append(k)

        required = [r for r in e.get("required", []) if r in props]
        schema = {"type": "object", "properties": props, "required": required}
        specs.append(ToolSpec(
            name=name, service=service, domain=slug(folder) or "general",
            description=e.get("description") or req.get("description") or it["name"],
            method=req["method"], url_template=url["raw"], params_schema=schema,
            path_params=path_p, query_params=query_p, body_keys=body_k,
            risk=e.get("risk", "read" if req["method"] == "GET" else "sensitive"),  # unknown writes default to sensitive
            example_queries=e.get("example_queries", []),
        ))
    return specs
