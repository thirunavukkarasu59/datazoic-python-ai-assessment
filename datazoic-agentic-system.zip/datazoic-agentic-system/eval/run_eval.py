"""Retrieval-only eval (no LLM, no network): does the right tool make it into the candidate set?
  python eval/run_eval.py [--hier]
recall@k = fraction of queries where ALL expected tools are in the top-k.
Separate from end-to-end success on purpose: if a run fails you want to know whether retrieval or the LLM was at fault."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from agent.ingest import load_postman          # noqa: E402
from agent.registry import ToolRegistry        # noqa: E402


def recall_at(reg, evalset, k, hier=None):
    hit, misses = 0, []
    for e in evalset:
        got = [s.name for s in reg.search(e["q"], k=k, hierarchical=hier)]
        if all(x in got for x in e["expect"]):
            hit += 1
        else:
            misses.append((e["q"], e["expect"], got[:k]))
    return hit / len(evalset), misses


if __name__ == "__main__":
    specs = load_postman(ROOT / "data/paypal_collection.postman.json", ROOT / "data/enrichment.json")
    reg = ToolRegistry(specs)
    ev = json.loads((ROOT / "eval/eval_set.json").read_text())
    hier = True if "--hier" in sys.argv else False
    print(f"{len(specs)} tools, {len(ev)} queries, hierarchical={hier}")
    for k in (1, 3, 5, 6, 8):
        r, _ = recall_at(reg, ev, k, hier)
        print(f"  recall@{k}: {r:.2f}")
    _, misses = recall_at(reg, ev, 6, hier)
    if misses:
        print("\nmisses @6:")
        for q, exp, got in misses:
            print(f"  - {q!r}\n      expected {exp}\n      got      {got}")
