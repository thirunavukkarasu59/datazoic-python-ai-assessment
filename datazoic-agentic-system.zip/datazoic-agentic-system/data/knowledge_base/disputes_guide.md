# Handling disputes (sample knowledge base)

## Dispute lifecycle
A dispute starts as an inquiry. If the buyer and seller cannot agree the inquiry can be escalated to a claim, after which PayPal reviews the case and decides. Sellers have a limited number of days to respond, shown in the allowed_response_options and seller_response_due_date fields.

## What evidence to provide
For items not received: tracking number with carrier, proof of delivery, and any correspondence. For services: signed agreements, completion confirmation. For not-as-described claims: product listing, photos, and communication with the buyer. Evidence is submitted through the provide-evidence action.

## Seller protection
Eligible transactions can be covered by seller protection if shipped to the address on the transaction details and proof of shipment is uploaded in time.
