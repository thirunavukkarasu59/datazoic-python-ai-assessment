"""Stress test: 25 real tools + 500 near-duplicate 'other service' tools (20 services x 25).
This is a WORST CASE for retrieval (every tool has a lookalike), not a realistic API catalogue.
It answers two questions: how does latency grow, and what rescues recall when tools collide?
  python scripts/scale_test.py"""
import copy
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "eval"))
from agent.ingest import load_postman      # noqa: E402
from agent.registry import ToolRegistry    # noqa: E402
from run_eval import recall_at             # noqa: E402

base = load_postman(ROOT / "data/paypal_collection.postman.json", ROOT / "data/enrichment.json")
ev = json.loads((ROOT / "eval/eval_set.json").read_text())
FAKE = ["stripe", "square", "adyen", "braintree", "razorpay", "mollie", "klarna", "wise", "revolut", "payoneer",
        "paddle", "checkout", "worldpay", "gocardless", "recurly", "chargebee", "zuora", "xero", "quickbooks", "freshbooks"]
specs = list(base)
for svc in FAKE:
    for s in base:
        c = copy.deepcopy(s)
        c.name, c.service = f"{svc}_{s.name}", svc
        specs.append(c)

t = time.time()
reg = ToolRegistry(specs)
print(f"{len(specs)} tools, index built in {time.time() - t:.2f}s")


def scoped_recall(k, **kw):
    hit = 0
    for e in ev:
        got = [s.name for s in reg.search(e["q"], k=k, **kw)]
        hit += all(x in got for x in e["expect"])
    return hit / len(ev)


def lat(**kw):
    t = time.time()
    for e in ev:
        reg.search(e["q"], k=6, **kw)
    return (time.time() - t) / len(ev) * 1000


print("\n                                        recall@6   recall@10   ms/query")
for label, kw in [("flat, no scoping", dict(hierarchical=False)),
                  ("hierarchical, no scoping", dict(hierarchical=True)),
                  ("flat + user's connected services", dict(hierarchical=False, services={"paypal"})),
                  ("hierarchical + connected services", dict(hierarchical=True, services={"paypal"}))]:
    print(f"{label:40s} {scoped_recall(6, **kw):.2f}       {scoped_recall(10, **kw):.2f}        {lat(**kw):.1f}")
